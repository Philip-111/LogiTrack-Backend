package org.logitrack.utils.payStackObjects;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Data {
     @JsonProperty("authorization_url")
     private String authorization_url;

     @JsonProperty("access_code")
     private String access_code;

     @JsonProperty("reference")
     private String reference;
}
