package org.logitrack.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import org.logitrack.utils.payStackObjects.Data;


@Builder
@Getter
@Setter
public class PaymentResponse {

    @JsonProperty("status")
    private boolean status;

    @JsonProperty("message")
    private String message;

    @JsonProperty("data")
    private Data data;


//    public boolean getStatus() { return status; }
//    @JsonProperty("status")
//    public void setStatus(boolean value) { this.status = value; }
//
//    @JsonProperty("message")
//    public String getMessage() { return message; }
//    @JsonProperty("message")
//    public void setMessage(String value) { this.message = value; }
//
//
//    public Data getData() { return data; }
//    @JsonProperty("data")
//    public void setData(Data value) { this.data = value; }
}
