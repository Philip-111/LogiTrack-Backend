package org.logitrack.entities;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import lombok.*;
import org.logitrack.enums.Status;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "transactions-2")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Transactions {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "userId", nullable = false)
    private User user;

    @Column(nullable = false)
    private String reference;

    @Column(nullable = false)
    private BigDecimal amount;

    @Column
    private String gatewayResponse;

    @Column(nullable = false)
    private Status transactionStatus;

    @Column(nullable = false)
    private String paidAt;

    @Column(nullable = false)
    private LocalTime createdAt;

    @Column(nullable = false)
    private LocalDate createdOn;
}
