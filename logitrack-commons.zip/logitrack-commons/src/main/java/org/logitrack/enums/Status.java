package org.logitrack.enums;

public enum Status {
    IN_PROGRESS,DELIVERED,FAILED,PENDING,SUCCESSFUL
}
