package org.logitrack.enums;

public enum Role {
    ADMIN,CUSTOMER,DELIVERY_MAN
}
