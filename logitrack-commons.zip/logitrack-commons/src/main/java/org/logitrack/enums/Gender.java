package org.logitrack.enums;

public enum Gender {
    MALE,FEMALE
}
