package org.logitrack.enums;

public enum OrderProgress {
    NEW,PENDING,COMPLETED
}
