package org.logitrack.exceptions;

public class CommonApplicationException extends Exception{
    public CommonApplicationException(String message) {
        super(message);
    }
}
